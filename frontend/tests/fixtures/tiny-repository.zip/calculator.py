"""A small arithmetic module for the real ZIP-ingestion browser test."""

def add(left: int, right: int) -> int:
    """Return the sum of two integers."""
    return left + right
